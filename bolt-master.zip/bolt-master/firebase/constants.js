export const FIREBASE_API_KEY = 'AIzaSyCtdzAMlk-ZI6Uanee6gMEOcSdbH1ujUso'
export const FIREBASE_AUTH_DOMAIN = 'bolt-246a8.firebaseapp.com'
export const FIREBASE_DATABASE_URL = 'https://bolt-246a8.firebaseio.com'
export const FIREBASE_PROJECT_ID = 'bolt-246a8'
export const FIREBASE_STORAGE_BUCKET = 'bolt-246a8.appspot.com'
export const FIREBASE_MESSAGING_SENDER_ID = '1025894580224'

export const FACEBOOK_APP_ID = '308739989674053'
