export { default as RestaurantRow } from './RestaurantRow.js';
